#include<stdio.h>
/*basic c program*/
int main()
{
	int i=0;
	char a;
	i = i + 1;
	printf("Hello World\n"); /*print on console*/
	return 0;
}
