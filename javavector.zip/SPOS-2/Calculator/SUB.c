#include <stdio.h>

int sub(int first, int second)
{
   printf("Subtraction is %d\n",(first-second));
   return (2);
}
